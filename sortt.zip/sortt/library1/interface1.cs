﻿namespace sortinterface;
public interface I100e
{
    void BubbleSort(int[] element);
    void InsertionSort(int[] element);
    void SelectionSort(int[] element);
    void MergeSort(int[] array, int left, int right);
    void Merge(int[] array, int left, int mid, int right);
}